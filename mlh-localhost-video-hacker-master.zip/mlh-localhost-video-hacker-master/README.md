# mlh-localhost-video-hacker
This repository holds the code for the MLH Localhost Module VideoHacker: Index and Analyze Videos with Microsoft Azure

# Video Explorer: Video Analysis on Microsoft Azure

## Video URLs

Use the following URLs to upload videos to the Video Indexer.

1. https://topcs.blob.core.windows.net/public/Overview-of-the-Microsoft-AI-School_high.mp4
2. https://topcs.blob.core.windows.net/public/Microsoft-in-Education_mid.mp4
3. https://topcs.blob.core.windows.net/public/Machine-Learning-in-IoT-solutions_high.mp4
